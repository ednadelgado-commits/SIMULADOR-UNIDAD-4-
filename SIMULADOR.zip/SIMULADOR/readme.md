
---

##  Tecnologías utilizadas

- [Three.js](https://threejs.org/) (versión r128)
- HTML5 / CSS3
- JavaScript (ES6)
- OrbitControls.js para navegación 3D

---

##  Funcionalidades

### Objetos
- Agregar cubos, esferas y cilindros.
- Duplicar y eliminar objetos.
- Selección de objetos con click en el canvas.

### Transformaciones
- Cambiar posición, rotación y escala usando sliders.
- Actualización en tiempo real sobre el objeto seleccionado.

### Rellenos y texturas
- Color homogéneo.
- Degradado por vértices.
- Aplicación de texturas (`textura1`, `textura2`, `textura3`).
- Shader fractal personalizado.

### Sombreado
- Constante (MeshBasicMaterial)
- Flat shading (MeshStandardMaterial con flatShading)
- Gouraud (MeshLambertMaterial)
- Phong (MeshPhongMaterial)
- Shader fractal personalizado

### Wireframe
- Alternar visualización de wireframe de cada objeto.

### Iluminación
- Luz ambiental, direccional y puntual.
- Ajuste de posición de luces direccionales.
- Cambios aplicados en tiempo real para ver efectos sobre sombras y reflexiones.

---

## Uso

1. Clonar o descargar el repositorio.
2. Abrir `index.html` en un navegador moderno (Chrome, Firefox, Edge).
3. Interactuar con la barra lateral para:
   - Agregar objetos 3D.
   - Modificar color, relleno, textura y sombreado.
   - Ajustar transformaciones y luces.
4. Hacer click en los objetos para seleccionarlos y aplicar cambios individuales.

---

##  Notas

- Las texturas deben estar en la carpeta `assets/texturas/`.
- La visualización requiere soporte WebGL (casi todos los navegadores modernos lo soportan).
- Se recomienda usar un **servidor local** si deseas cargar texturas correctamente, ya que algunos navegadores bloquean la carga de archivos locales por seguridad.

---

## Estilos

- Colores y gradientes definidos en `style.css`.
- Diseño tipo **sidebar** para control de objetos y parámetros.
- Canvas ocupa toda la pantalla restante para visualización 3D.

---

## Referencias

- [Three.js Documentation](https://threejs.org/docs/)
- [OrbitControls.js](https://threejs.org/docs/#examples/en/controls/OrbitControls)

---


